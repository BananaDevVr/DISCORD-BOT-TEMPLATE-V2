const { Client, Intents, MessageEmbed } = require('discord.js');

const client = new Client({
  intents: [
    Intents.FLAGS.GUILDS,
    Intents.FLAGS.GUILD_MEMBERS,
    Intents.FLAGS.GUILD_MESSAGES,
  ],
});

client.once('ready', () => {
  console.log('Bot is ready!');
  client.user.setActivity('!HELP', { type: 'PLAYING' });
});

const prefix = '!';
const allowedUsers = ['790779695871950848', '1147349171507040256'];
const generalModerators = ['CSVR', 'Banana', 'DINO', 'And Developers'];

const streamModerators = ['Unkown', 'Banana', 'TMM Crystal', 'LynxVr', 'Faaduu', 'OEN_dub', 'VaporAR', 'Fireluke Gaming', 'OnlyExpertPlus', 'MezeTheMonkey', 'JaysXtremeGaming', 'Beat Saber Official', 'Serbian army', 'Goofy', 'GTagPlayer3046', 'Kitty :0', 'Seiteki', 'Elhajep_VR', 'Zenyx VR'];

client.on('messageCreate', (message) => {
  if (message.guild) {
    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === 'ping') {
      const pingEmbed = new MessageEmbed()
        .setColor('#0099ff')
        .setTitle('Ping Pong!')
        .setDescription(`Bot latency: ${Date.now() - message.createdTimestamp}ms`);
      message.reply({ embeds: [pingEmbed] });
    } else if (command === 'updatelog') {
      const updateLogEmbed = new MessageEmbed()
        .setColor('#ff9900')
        .setTitle('Update Log')
        .setDescription('Recent updates and changes:')
        .addField('V1_BETA', 'Brought Bunch of Commands and Limited To Source')
        .addField('V1.5', 'Bunch of Errors fixed')
        .addField('Update 3', 'OPEN SOURCE + Dashboard');

      message.reply({ embeds: [updateLogEmbed] });
    } else if (command === 'credits') {
      const creditsEmbed = new MessageEmbed()
        .setColor('#3498db')
        .setTitle('Bot Credits')
        .setDescription('This bot was developed by Bananadevvr.')
        .addField('Contributors', 'CSVR, DINO')
        .addField('GitHub Repository', '[Link to GitHub Repo](Coming Soon)')
        .setFooter('Thank you for using this bot!');

      message.reply({ embeds: [creditsEmbed] });
    } else if (command === 'say') {
      // Check if the user has permission to use !say
      if (!allowedUsers.includes(message.author.id)) {
        message.reply('You do not have permission to use the !say command.');
        return;
      }

      // Delete the original message
      message.delete();

      // Get the remaining part of the message (what the person wants to say)
      const sayMessage = args.join(' ');

      // Send the repeated message to the public chat
      message.channel.send(`${sayMessage}`);
    } else if (command === 'help') {
      const helpEmbed = new MessageEmbed()
        .setColor('#3498db')
        .setTitle('CSVRStudiosProBeta Bot Commands')
        .setDescription('Here is a list of available commands:')
        .addField('!ping', 'Check the bot\'s latency.')
        .addField('!updatelog', 'View recent updates and changes.')
        .addField('!credits', 'Get information about the bot and its contributors.')
        .addField('!say <message>', 'Make the bot repeat a message (Admins only).')
        .addField('!help', 'Display this help message.');

      message.channel.send({ embeds: [helpEmbed] });
    } else if (command === 'modlist') {
      // Create a modlist embed based on the context
      const moderators = message.channel.type === 'GUILD_TEXT' ? generalModerators : streamModerators;

      const modlistEmbed = new MessageEmbed()
        .setColor('#3498db')
        .setTitle('Moderator List')
        .setDescription('Here is a list of moderators:')
        .addField('Moderators', moderators.join(', '));

      // Send the modlist embed to the channel
      message.channel.send({ embeds: [modlistEmbed] });
    } else if (command === '8ball') {
      if (!args.length) {
        return message.reply('Please ask a question for the magic 8-ball.');
      }

      const responses = [
        'It is certain.',
        'It is decidedly so.',
        'Without a doubt.',
        'Yes – definitely.',
        'You may rely on it.',
        'As I see it, yes.',
        'Most likely.',
        'Outlook good.',
        'Yes.',
        'No.',
        'Ask again later.',
        'Cannot predict now.',
        'Don\'t count on it.',
        'My sources say no.',
        'Outlook not so good.',
        'Very doubtful.',
      ];

      const response = responses[Math.floor(Math.random() * responses.length)];

      const eightBallEmbed = new MessageEmbed()
        .setColor('#3498db')
        .setTitle('🎱 Magic 8-Ball 🎱')
        .addField('Question', args.join(' '))
        .addField('Answer', response);

      message.reply({ embeds: [eightBallEmbed] });
    }
  }
});

const discordToken = 'MTE5NDA5NDYwODY0MTE2NzUwMQ.Gm4S2b.m_7X2vIo9EflzcUhmB_MxtLzkxE5CRUScM-8do';
client.login(discordToken);